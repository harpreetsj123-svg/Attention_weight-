#!/usr/bin/env bash
# Reproduce the result tables, figures and algorithm checks.
set -euo pipefail
cd "$(dirname "$0")/.."
export PYTHONPATH=src

echo ">> validating ARCA identities"
python tests/test_arca_completeness.py
python tests/test_metrics.py

echo ">> regenerating Tables 3-5"
python -m arca.figures.make_tables

echo ">> regenerating Figures 2-3"
python -m arca.figures.make_figures

echo ">> (optional) full pipeline on synthetic regimes"
echo "   python -m arca.experiments.run_all --out results/runs"

echo "done. See results/tables and results/figures."
