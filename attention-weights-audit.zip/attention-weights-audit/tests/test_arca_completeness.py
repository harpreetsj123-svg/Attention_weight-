"""
Numerical validation of the ARCA identities (Section 4.3) on a small, fully
specified attention model -- pure NumPy, no torch required, so it runs anywhere.

Model (one attention layer over scalar feature "tokens"):

    routing   A_i(x) = softmax(c * x)_i          (depends on x)
    value     V_i(x) = v_i * x_i                  (linear value path)
    logit     f(x)   = sum_i A_i(x) * V_i(x)

ARCA integrates the gradient from x_bar to x over m midpoints and splits it into
    value channel   : gradient with A *replayed from the recorded routing A(x)*
                      (held constant across the path), following conservative
                      propagation; and
    routing channel : the remainder.

Checks:
    C1 completeness ....... sum(total)  ~= f(x) - f(x_bar)
    C2 exact split ........ total == value + routing   (to machine precision)
    C3 routing meaning .... sum(value)  ~= f(x) - f(x_bar; A = A(x))  and hence
                            sum(routing) ~= f(x_bar; A = A(x)) - f(x_bar), i.e. the
                            output change from the background routing to the
                            recorded routing of x.
    C4 linear reduction ... c = 0  =>  routing ~= 0 and total == interventional
                            Shapley of the linear value model.
"""
import numpy as np


def softmax(z):
    z = z - z.max(-1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(-1, keepdims=True)


def make_model(d, c, seed=0):
    rng = np.random.default_rng(seed)
    v = rng.normal(size=d)

    def f(x, A_fixed=None):
        A = softmax(c * x) if A_fixed is None else A_fixed
        return (A * (v * x)).sum(-1)

    def grad_total(x):
        # analytic gradient of f wrt x (routing varies)
        A = softmax(c * x)
        val = v * x
        # d f / d x_k = A_k v_k + sum_i (dA_i/dx_k) val_i
        # dA_i/dx_k = c A_i (delta_ik - A_k)
        base = A * v
        s = (A * val).sum()
        route = c * A * (val - s)            # sum_i dA_i/dx_k val_i = c A_k(val_k - sum A val)
        return base + route

    def grad_value(x, A_rec):
        # routing replayed from the recorded A(x) (held constant) -> value path only
        return A_rec * v

    return f, grad_total, grad_value, v


def arca_numpy(f, grad_total, grad_value, x, x_bar, c, m=64):
    diff = x - x_bar
    A_rec = softmax(c * x)                     # routing recorded at the instance
    gt = np.zeros_like(x)
    gv = np.zeros_like(x)
    for k in range(m):
        a = (k + 0.5) / m
        xa = x_bar + a * diff
        gt += grad_total(xa)
        gv += grad_value(xa, A_rec)
    gt /= m
    gv /= m
    total = diff * gt
    value = diff * gv
    routing = total - value
    return total, value, routing, A_rec


def interventional_shapley_linear(v, A_bar, x, x_bar):
    """For f = sum_i A_bar_i v_i x_i (fixed routing), interventional Shapley is
    phi_i = A_bar_i v_i (x_i - x_bar_i)."""
    return A_bar * v * (x - x_bar)


def run():
    rng = np.random.default_rng(3)
    d = 6
    x = rng.normal(size=d)
    x_bar = rng.normal(size=d) * 0.3

    # --- routing-dependent model (c != 0) ---
    f, gt, gv, v = make_model(d, c=1.7, seed=1)
    total, value, routing, A_rec = arca_numpy(f, gt, gv, x, x_bar, c=1.7, m=256)
    delta = f(x) - f(x_bar)

    c1 = abs(total.sum() - delta)
    c2 = np.max(np.abs(total - (value + routing)))
    # value completeness: sum(value) == f(x) - f(x_bar; A = A(x))
    f_xbar_Arec = f(x_bar, A_fixed=A_rec)
    c3_value = abs(value.sum() - (f(x) - f_xbar_Arec))
    # routing meaning: sum(routing) == f(x_bar; A(x)) - f(x_bar)
    c3_route = abs(routing.sum() - (f_xbar_Arec - f(x_bar)))

    print(f"[C1] completeness residual   |sum(total) - df|      = {c1:.2e}")
    print(f"[C2] exact split max|t-(v+r)|                        = {c2:.2e}")
    print(f"[C3] value completeness residual                     = {c3_value:.2e}")
    print(f"[C3] routing meaning residual                        = {c3_route:.2e}")

    # --- linear reduction (c = 0 => routing independent of x) ---
    f0, gt0, gv0, v0 = make_model(d, c=0.0, seed=1)
    t0, val0, rout0, _ = arca_numpy(f0, gt0, gv0, x, x_bar, c=0.0, m=256)
    A_unif = np.full(d, 1.0 / d)
    shap = interventional_shapley_linear(v0, A_unif, x, x_bar)
    c4_route = np.max(np.abs(rout0))
    c4_shap = np.max(np.abs(t0 - shap))
    print(f"[C4] linear: max|routing|                            = {c4_route:.2e}")
    print(f"[C4] linear: max|total - interventional Shapley|     = {c4_shap:.2e}")

    assert c1 < 1e-3, c1
    assert c2 < 1e-10, c2
    assert c3_value < 1e-3, c3_value
    assert c3_route < 1e-3, c3_route
    assert c4_route < 1e-10, c4_route
    assert c4_shap < 1e-3, c4_shap
    print("\nALL ARCA IDENTITY CHECKS PASSED")


def test_arca_identities():      # pytest entry point
    run()


if __name__ == "__main__":
    run()
