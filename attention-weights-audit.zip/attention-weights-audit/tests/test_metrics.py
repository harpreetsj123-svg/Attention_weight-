"""Smoke tests for the evaluation metrics and oracle recovery (NumPy only)."""
import os, sys
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from arca.evaluation import (mean_kendall, precision_at_k, kendalls_w,
                             redundancy_split_index, paired_diff_ci)
from arca.data import build
from arca.attributions.oracles import linear_oracle


def test_kendall_perfect():
    phi = np.array([[3., 1., 2., 0.]])
    assert abs(mean_kendall(phi, phi) - 1.0) < 1e-9


def test_precision_at_k():
    phi = np.array([[5., 4., 0.1, 0.2]])
    assert precision_at_k(phi, [0, 1], k=2) == 1.0
    assert precision_at_k(phi, [2, 3], k=2) == 0.0


def test_kendalls_w_identical():
    ranks = np.array([[1, 2, 3, 4], [1, 2, 3, 4], [1, 2, 3, 4]])
    assert abs(kendalls_w(ranks) - 1.0) < 1e-9


def test_rsi_even_split():
    phi = np.array([[1.0, 1.0, 1.0]])
    rsi, share = redundancy_split_index(phi, [0, 1, 2])
    assert abs(rsi - 1.0) < 1e-9 and abs(share - 1 / 3) < 1e-9


def test_linear_oracle_recovers_drivers():
    reg = build("T1", n=4000, seed=0)
    phi, info = linear_oracle(reg.X, reg.latent)
    # top-5 features by mean |phi| should include the 5 true parents (f00..f04)
    top = set(np.argsort(-np.abs(phi).mean(0))[:5])
    assert len(top & set(range(5))) >= 4
    assert info["r2"] > 0.5


if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn(); print("ok", name)
    print("ALL METRIC TESTS PASSED")
