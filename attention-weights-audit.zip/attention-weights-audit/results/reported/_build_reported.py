"""
Write the reported result values of the paper to CSV.

These are the published summary values from Tables 3-5 and the panels of Figs 2-3.
``make_tables.py`` and ``make_figures.py`` read them to regenerate the exact
camera-ready tables and figures.  Running the full pipeline on the Kaggle data
(see README) overwrites these with freshly computed values.
"""
import os
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))


def w(df, name):
    df.to_csv(os.path.join(HERE, name), index=False)
    print("wrote", name, df.shape)


# ---- Table 3: predictive performance (mean +/- 95% CI half-width) -----------
t3 = pd.DataFrame([
    ["T1", "AUPRC", 0.845, 0.843, 0.843, 0.841, 0.839, 0.843, 0.843, None, None],
    ["T1", "AUROC", 0.925, 0.924, 0.924, 0.923, 0.922, 0.924, 0.924, None, None],
    ["T2", "AUPRC", 0.457, 0.455, 0.455, 0.452, 0.433, 0.449, 0.456, None, None],
    ["T2", "AUROC", 0.660, 0.659, 0.658, 0.655, 0.639, 0.652, 0.659, None, None],
    ["T4", "AUPRC", 0.331, 0.328, 0.329, 0.328, 0.329, 0.319, 0.329, 0.331, 0.377],
    ["T4", "AUROC", 0.575, 0.571, 0.573, 0.572, 0.571, 0.555, 0.572, 0.575, 0.604],
    ["T5", "AUPRC", 0.966, 0.952, 0.961, 0.948, 0.960, 0.878, 0.952, None, None],
    ["T5", "AUROC", 0.993, 0.990, 0.991, 0.991, 0.989, 0.960, 0.991, None, None],
], columns=["task", "metric", "LR", "MLP", "EBM", "XGBoost", "LightGBM",
            "TabNet", "FT-T", "Oracle_obs", "Oracle_pgen"])
# 95% CI half-widths over folds
ci = pd.DataFrame([
    ["T1", "AUPRC", .002, .002, .002, .002, .002, .002, .001],
    ["T1", "AUROC", .002, .001, .002, .002, .002, .002, .001],
    ["T2", "AUPRC", .008, .007, .007, .006, .005, .006, .007],
    ["T2", "AUROC", .004, .004, .004, .003, .004, .005, .004],
    ["T4", "AUPRC", .005, .005, .003, .004, .005, .007, .004],
    ["T4", "AUROC", .004, .003, .003, .005, .005, .011, .004],
    ["T5", "AUPRC", .009, .013, .011, .017, .012, .031, .013],
    ["T5", "AUROC", .002, .003, .003, .003, .005, .019, .003],
], columns=["task", "metric", "LR", "MLP", "EBM", "XGBoost", "LightGBM", "TabNet", "FT-T"])
w(t3, "table3_means.csv")
w(ci, "table3_ci.csv")

# ---- Table 4: oracle agreement / precision / deletion / cost ----------------
cols4 = ["explainer",
         "T1_tau", "T1_p", "T1_Fdel", "T3_tau", "T3_p", "T3_Fdel",
         "T4_tau", "T4_p", "T4_Fdel", "T5_tau", "T5_p", "T5_Fdel", "cost_ms"]
t4 = pd.DataFrame([
    ["FT-T [CLS] attention", .27, .61, .68, .38, .62, .94, .27, .57, 1.06, .12, .48, .82, 1.47],
    ["FT-T rollout",         .32, .67, .80, .50, .69, .98, .30, .59, 1.08, .30, .71, .95, 1.47],
    ["FT-T grad-attention",  .08, .54, .88, .22, .50, .99, .05, .46, .52, .15, .37, .44, 1.47],
    ["FT-T ARCA-V",          .71, .87, 1.00, .49, .69, .97, .41, .65, 1.17, .46, .83, .95, 7.19],
    ["FT-T ARCA",            .72, .87, 1.00, .52, .72, .99, .40, .64, 1.15, .37, .50, .87, 14.4],
    ["FT-T SHAP",            .72, .88, 1.01, .61, .83, 1.00, .46, .68, 1.22, .36, .98, 1.03, 461.0],
    ["TabNet mask",          .18, .56, .63, .63, .72, .92, .08, .43, .94, .18, .31, 1.21, .54],
    ["TabNet ARCA-V",        .23, .57, .72, .65, .75, .97, .09, .43, 1.10, .26, .43, 1.30, 5.15],
    ["TabNet ARCA",          .72, .95, 1.01, .55, .77, .99, .14, .46, 1.45, .32, .44, .96, 10.3],
    ["TabNet SHAP",          .71, .94, 1.00, .59, .81, 1.00, .21, .50, 1.87, .28, .77, 1.32, 130.0],
    ["XGBoost TreeSHAP",     .70, .94, 1.01, .61, .85, 1.00, .45, .67, 1.15, .28, 1.00, 1.00, 7.36],
    ["LR SHAP (exact)",      .74, .93, 1.00, .63, .88, 1.00, .44, .64, .93, .44, .94, 1.00, 0.009],
], columns=cols4)
w(t4, "table4.csv")

# ---- Fig 3(a) oracle-agreement heatmap (tau per explainer x regime) ---------
heat = t4[["explainer", "T1_tau", "T3_tau", "T4_tau", "T5_tau"]].copy()
# add EBM terms row (glass-box reference reported in Fig 3a)
heat = pd.concat([heat, pd.DataFrame(
    [["EBM terms", .73, .63, .47, .27]],
    columns=["explainer", "T1_tau", "T3_tau", "T4_tau", "T5_tau"])], ignore_index=True)
heat.columns = ["explainer", "R1", "R2", "R3", "R4"]
w(heat, "fig3_heatmap.csv")

# ---- Table 5: seed stability -------------------------------------------------
cols5 = ["explainer", "seedtau_R4", "seedtau_R2", "jac_R4", "jac_R2", "lipschitz",
         "rsi_perf", "rsi_perf_sd", "rsi_sat", "rsi_sat_sd", "classtau_R2"]
t5 = pd.DataFrame([
    ["LR SHAP (exact)", 1.00, 1.00, 1.00, 1.00, 0.45, 1.00, 0.00, 1.00, 0.00, 0.64],
    ["XGBoost TreeSHAP", 0.77, 0.92, 0.72, 0.87, 0.19, 0.90, 0.03, 0.83, 0.09, 0.62],
    ["TabNet mask", 0.50, 0.55, 0.50, 0.56, 2.04, 0.63, 0.38, 0.79, 0.29, 0.76],
    ["TabNet ARCA", 0.24, 0.57, 0.56, 0.57, 7.90, 0.43, 0.44, 0.83, 0.26, 0.62],
    ["TabNet SHAP", 0.30, 0.54, 0.51, 0.56, 1.90, 0.41, 0.46, 0.91, 0.16, 0.57],
    ["FT-T [CLS] attention", 0.14, 0.45, 0.48, 0.61, 0.05, 0.94, 0.15, 0.99, 0.08, 0.42],
    ["FT-T rollout", 0.23, 0.51, 0.50, 0.69, 0.01, 0.98, 0.09, 1.00, 0.04, 0.42],
    ["FT-T ARCA-V", 0.14, 0.68, 0.58, 0.69, 0.55, 0.99, 0.07, 0.92, 0.17, 0.54],
    ["FT-T ARCA", 0.17, 0.78, 0.57, 0.68, 0.58, 0.90, 0.18, 0.93, 0.17, 0.50],
    ["FT-T SHAP", 0.13, 0.75, 0.53, 0.78, 0.22, 0.87, 0.22, 0.83, 0.13, 0.59],
], columns=cols5)
w(t5, "table5.csv")

# ---- Fig 2(a) ROC summary and (b) confusion matrices ------------------------
roc = pd.DataFrame([
    ["T1", 0.923, 0.920, 0.925], ["T2", 0.657, 0.652, 0.660],
    ["T3", 1.000, 0.999, 1.000], ["T4", 0.570, 0.553, 0.575],
    ["T5", 0.981, 0.960, 0.993],
], columns=["task", "FT-T", "TabNet", "best_ref"])
w(roc, "fig2_roc.csv")

conf = pd.DataFrame([
    ["T1", 62142, 9282, 5868, 22708],
    ["T2", 26772, 41226, 5970, 26032],
    ["T3", 48784, 483, 351, 50382],
    ["T4", 12037, 59593, 3011, 25369],
    ["T5", 1489, 38, 30, 243],
], columns=["task", "TN", "FP", "FN", "TP"])
w(conf, "fig2_confusion.csv")

print("done")
