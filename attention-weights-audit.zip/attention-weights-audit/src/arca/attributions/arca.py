"""
ARCA - Attention-Routed Contrastive Attribution.

Implements Algorithm 1 and Eqs (9)-(12).  ARCA integrates the gradient of the
logit along a straight path from a background-mean reference ``x_bar`` to the
instance ``x`` and splits the result **exactly** into

    * a *value* channel   - credit carried along the value paths opened by the
      recorded routing (attention / masks), computed with the routing detached
      and replayed as a constant, following conservative propagation [24]; and
    * a *routing* channel  - the remainder, i.e. the output change caused by the
      change in the routing itself.

Properties proved in the paper and checked in ``tests/test_arca_completeness.py``:

  (C1) completeness .......... sum(total)  = f(x) - f(x_bar)   as m -> inf
  (C2) exact split ........... total = value + routing         (per feature)
  (C3) routing meaning ....... sum(routing) = f(x) - f_frozen(x; R=R(x_bar))
  (C4) linear reduction ...... for an input-linear net with input-independent
                               routing, routing == 0 and total == interventional
                               Shapley value.

The model must expose ``freeze_routing(flag: bool)`` (a context flag that detaches
attention probabilities and LayerNorm statistics for FT-Transformer, or the step
masks for TabNet) and a ``forward``/``__call__`` returning a scalar logit per row.
"""
from __future__ import annotations
from dataclasses import dataclass
from contextlib import contextmanager
from typing import Optional
import numpy as np

try:
    import torch
except Exception:                                   # torch optional at import time
    torch = None


@dataclass
class ArcaResult:
    total: np.ndarray        # (n, d) total attribution  phi
    value: np.ndarray        # (n, d) value channel      phi_V
    routing: np.ndarray      # (n, d) routing channel    phi - phi_V
    routing_share: np.ndarray  # (n,) per-instance routing share, Eq (11)
    completeness_residual: np.ndarray  # (n,) |sum(total) - (f(x)-f(x_bar))| / |df|
    delta: np.ndarray        # (n,) f(x) - f(x_bar)


@contextmanager
def _replay(model, flag: bool):
    prev = getattr(model, "_freeze_routing", False)
    model.set_replay(flag)
    try:
        yield
    finally:
        model.set_replay(prev)


def _grad_logit(model, x, replay: bool):
    """Return (logit.detach, d logit / d x) for a batch x.

    When ``replay`` is True the routing recorded at the instance (via
    ``model.record_routing``) is replayed as a constant, so the gradient flows
    only through the value paths (the value channel)."""
    x = x.clone().detach().requires_grad_(True)
    with _replay(model, replay):
        out = model(x)
        if out.ndim > 1:
            out = out.squeeze(-1)
        g, = torch.autograd.grad(out.sum(), x, create_graph=False)
    return out.detach(), g.detach()


def arca(model,
         X,
         background: Optional["np.ndarray"] = None,
         m: int = 8,
         device: str = "cpu") -> ArcaResult:
    """Compute ARCA for every row of ``X``.

    Parameters
    ----------
    model       : torch model exposing ``freeze_routing(bool)`` and returning a logit.
    X           : (n, d) array/tensor of instances to explain.
    background  : (b, d) background set; its mean is the reference x_bar.  If None,
                  the mean of ``X`` is used.
    m           : number of path points (default 8, as in the paper).
    """
    if torch is None:
        raise ImportError("ARCA requires PyTorch; `pip install torch`.")
    model.eval()
    X = torch.as_tensor(np.asarray(X), dtype=torch.float32, device=device)
    n, d = X.shape
    if background is None:
        x_bar = X.mean(0, keepdim=True)
    else:
        bg = torch.as_tensor(np.asarray(background), dtype=torch.float32, device=device)
        x_bar = bg.mean(0, keepdim=True)
    x_bar = x_bar.expand(n, d)

    diff = X - x_bar                                     # (n, d)

    # Record the routing A(x) at the instances once; the value channel replays it.
    model.record_routing(X)

    # midpoint rule over m path points for both channels
    g_tot = torch.zeros_like(X)
    g_val = torch.zeros_like(X)
    alphas = (torch.arange(m, device=device) + 0.5) / m  # midpoints
    for a in alphas:
        xa = x_bar + a * diff
        _, gt = _grad_logit(model, xa, replay=False)     # total: routing varies
        _, gv = _grad_logit(model, xa, replay=True)      # value: routing = A(x)
        g_tot += gt
        g_val += gv
    g_tot /= m
    g_val /= m

    total = (diff * g_tot).cpu().numpy()
    value = (diff * g_val).cpu().numpy()
    routing = total - value

    # f(x) - f(x_bar)   (routing free)
    with torch.no_grad(), _replay(model, False):
        fx = model(X).squeeze(-1)
        fb = model(x_bar[:1]).squeeze(-1)
    delta = (fx - fb).cpu().numpy()

    sval = np.abs(value).sum(1)
    srout = np.abs(routing).sum(1)
    routing_share = srout / np.clip(sval + srout, 1e-12, None)

    denom = np.clip(np.abs(delta), 1e-8, None)
    comp_res = np.abs(total.sum(1) - delta) / denom

    return ArcaResult(total, value, routing, routing_share, comp_res, delta)


def arca_abs(res: ArcaResult) -> np.ndarray:
    """Unsigned attribution used for comparison with the unsigned oracle/attention."""
    return np.abs(res.total)
