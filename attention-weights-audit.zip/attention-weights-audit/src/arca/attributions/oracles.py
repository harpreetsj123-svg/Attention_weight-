"""
Oracle (ground-truth) attributions recovered from each generator (Section 4.1).

    R1, R4 (linear regimes)  : interventional Shapley of a fitted linear oracle,
                               closed form  phi*_i = w_i (x_i - E[x_i])   (Eq 2).
    R2 (saturating)          : exact interventional Shapley of a gradient-boosted
                               surrogate over the 4 parents (16 coalitions, Eqs 3-4).
    R3 (noise-limited)       : interventional Shapley of a surrogate of p_gen over
                               the recovered parents (exact for <= ~12 parents).

NOTE: the R1/R4/R3 oracles are *fitted surrogates* (R^2 = 0.714 / 0.922 / 0.410 on
the real data); only the R2 surrogate is near-exact (R^2 = 0.998).  Agreement with
these oracles is agreement with a benchmark, not with the true generating process.
"""
from __future__ import annotations
from itertools import combinations
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import GradientBoostingRegressor


def linear_oracle(X, latent):
    """Closed-form interventional Shapley of a linear oracle fitted on (X, latent)."""
    reg = LinearRegression().fit(X, latent)
    w = reg.coef_
    mu = X.mean(0)
    phi = (X - mu) * w                      # (n, d)
    r2 = reg.score(X, latent)
    return phi, {"r2": float(r2), "w": w}


def _exact_shapley(f, X, parents, background, max_parents=12):
    """Exact interventional Shapley over `parents` using a background set.

    v(S) = E_background[ f( x on S, background off S ) ].  For p parents this is
    2^p coalition evaluations; used for the 4-parent R2/R3 oracles.
    """
    n, d = X.shape
    p = len(parents)
    if p > max_parents:
        raise ValueError("too many parents for exact Shapley")
    bg = background
    phi = np.zeros((n, d))
    # precompute coalition values per instance, averaged over background rows
    subsets = []
    for r in range(p + 1):
        subsets += list(combinations(range(p), r))
    sset = set(subsets)

    def v(mask_idx, x):
        # build matrix: parents in S -> x value; others -> background rows
        B = np.tile(bg, (1, 1)).astype(float)          # (b, d)
        B = np.repeat(x[None, :], bg.shape[0], axis=0).copy()
        # set non-S parents to background, keep S parents at x, non-parents to background
        keep = np.zeros(d, dtype=bool)
        for j, pi in enumerate(parents):
            if j in mask_idx:
                keep[pi] = True
        for col in range(d):
            if not keep[col]:
                B[:, col] = bg[:, col]
        return f(B).mean()

    from math import factorial
    weights = {len(S): factorial(len(S)) * factorial(p - len(S) - 1) / factorial(p)
               for S in subsets if len(S) < p}
    for i in range(n):
        x = X[i]
        cache = {}
        def vv(S):
            S = tuple(sorted(S))
            if S not in cache:
                cache[S] = v(S, x)
            return cache[S]
        for j, pi in enumerate(parents):
            s = 0.0
            others = [q for q in range(p) if q != j]
            for r in range(len(others) + 1):
                for S in combinations(others, r):
                    s += weights[len(S)] * (vv(S + (j,)) - vv(S))
            phi[i, pi] = s
    return phi


def gb_shapley_oracle(X_oracle, target_oracle, X_explain, parents, n_bg=64, seed=0):
    """Fit a GB surrogate on the oracle sample and return its exact interventional
    Shapley on X_explain over `parents` (R2 and R3)."""
    sur = GradientBoostingRegressor(max_depth=3, n_estimators=200, random_state=seed)
    sur.fit(X_oracle, target_oracle)
    rng = np.random.default_rng(seed)
    bg = X_oracle[rng.choice(len(X_oracle), size=min(n_bg, len(X_oracle)), replace=False)]
    f = lambda B: sur.predict(B)
    phi = _exact_shapley(f, X_explain, parents, bg)
    return phi, {"r2": float(sur.score(X_oracle, target_oracle))}


def oracle_for(regime, X_explain, n_bg=64):
    """Dispatch: return (phi*, info) for a Regime bundle on the rows X_explain."""
    rg = regime.regime
    if rg in ("R1", "R4"):
        # fit the linear oracle on the regime's own latent score
        phi_all, info = linear_oracle(regime.X, regime.latent)
        # map to explained rows by recomputing with the same weights
        mu = regime.X.mean(0)
        phi = (X_explain - mu) * info["w"]
        return phi, info
    elif rg == "R2":
        return gb_shapley_oracle(regime.X, regime.latent, X_explain, regime.parent_idx, n_bg)
    elif rg == "R3":
        tgt = regime.p_gen if regime.p_gen is not None else regime.latent
        return gb_shapley_oracle(regime.X, tgt, X_explain, regime.parent_idx, n_bg)
    raise KeyError(rg)
