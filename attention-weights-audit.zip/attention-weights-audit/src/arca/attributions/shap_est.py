"""
SHAP estimators used as the comparator (Section 4.4, Eq 13).

    * linear_shap   - exact for logistic regression
    * tree_shap     - interventional TreeSHAP for XGBoost (falls back to the
                      antithetic permutation estimator if `shap` is absent)
    * perm_shap     - antithetic permutation estimator with a shared background of
                      50 stratified rows and P permutations (default 6), used for
                      TabNet and FT-Transformer.

All estimators share one interventional value function and one background set so
that explainer quality is separated from model quality (same-model SHAP).
"""
from __future__ import annotations
import numpy as np


def perm_shap(f, X, background, n_perm=6, seed=0, antithetic=True):
    """Antithetic permutation SHAP of a scalar function ``f`` (logit).

    f : callable (m, d) -> (m,).  Background mean-interventional value function:
    features before i in the permutation are taken from x, the rest from a
    background row; averaged over the background set and the permutations.
    """
    rng = np.random.default_rng(seed)
    n, d = X.shape
    bg = np.asarray(background)
    phi = np.zeros((n, d))
    for p in range(n_perm):
        order = rng.permutation(d)
        orders = [order, order[::-1]] if antithetic else [order]
        for order in orders:
            for b in bg:                       # average over background rows
                for xi in range(n):
                    x = X[xi]
                    z = b.copy()
                    prev = f(z[None, :])[0]
                    for j in order:
                        z[j] = x[j]
                        cur = f(z[None, :])[0]
                        phi[xi, j] += cur - prev
                        prev = cur
    phi /= (n_perm * (2 if antithetic else 1) * len(bg))
    return phi


def perm_shap_fast(f, X, background, n_perm=6, seed=0):
    """Vectorised antithetic permutation SHAP (batched over instances & background)."""
    rng = np.random.default_rng(seed)
    n, d = X.shape
    bg = np.asarray(background)
    b = len(bg)
    phi = np.zeros((n, d))
    count = 0
    for p in range(n_perm):
        base = rng.permutation(d)
        for order in (base, base[::-1]):
            count += 1
            for bi in range(b):
                Z = np.repeat(bg[bi][None, :], n, axis=0)   # (n, d) start = background
                prev = f(Z)
                for j in order:
                    Z[:, j] = X[:, j]
                    cur = f(Z)
                    phi[:, j] += cur - prev
                    prev = cur
    return phi / (count * b)


def linear_shap(clf, X, background):
    """Exact SHAP for a linear/logistic model: w_i (x_i - E_bg[x_i]) on the logit."""
    w = np.asarray(clf.coef_).ravel()
    mu = np.asarray(background).mean(0)
    return (X - mu) * w


def tree_shap(clf, X):
    """Interventional TreeSHAP via the `shap` package, if available."""
    try:
        import shap
        expl = shap.TreeExplainer(clf, feature_perturbation="interventional")
        sv = expl.shap_values(X)
        if isinstance(sv, list):
            sv = sv[1]
        return np.asarray(sv)
    except Exception:
        # fall back to a cheap permutation estimate on predict_proba logit
        def f(Z):
            p = np.clip(clf.predict_proba(Z)[:, 1], 1e-6, 1 - 1e-6)
            return np.log(p / (1 - p))
        bg = X[np.random.default_rng(0).choice(len(X), size=min(50, len(X)), replace=False)]
        return perm_shap_fast(f, X, bg, n_perm=6)
