"""
Thin wrappers around the native attention readouts of the two networks so the
evaluation protocol can treat every explainer uniformly (all unsigned, Eq 1).
"""
from __future__ import annotations
import numpy as np


def ft_readouts(model, X):
    """Return the three FT-Transformer readouts as unsigned attributions."""
    return {
        "FT-T [CLS] attention": np.abs(model.readout_cls(X)),
        "FT-T rollout": np.abs(model.readout_rollout(X)),
        "FT-T grad-attention": np.abs(model.readout_grad(X)),
    }


def tabnet_readout(model, X):
    return {"TabNet mask": np.abs(model.readout_mask(X))}
