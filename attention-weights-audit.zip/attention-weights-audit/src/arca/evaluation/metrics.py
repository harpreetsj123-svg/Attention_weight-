"""
Evaluation metrics for the E1-E5 protocol (Section 4.5).

E1  oracle agreement : per-instance Kendall tau and precision@|P|
E2  deletion/insertion faithfulness, normalised between random and oracle (Eq 14)
E3  counterfactual faithfulness (handled by the model's permute_* methods, Eq 15)
E4  stability : seed Kendall tau, top-k Jaccard, local Lipschitz, RSI (Eq 16)
E5  replication : Kendall's W across regimes; construct-level agreement
"""
from __future__ import annotations
import numpy as np
from scipy.stats import kendalltau


# ----------------------------- E1 ---------------------------------------------
def mean_kendall(phi, phi_star):
    """Mean per-instance Kendall tau between |phi| and |phi*| (unsigned)."""
    a, b = np.abs(phi), np.abs(phi_star)
    taus = []
    for i in range(a.shape[0]):
        if np.allclose(a[i], a[i][0]) or np.allclose(b[i], b[i][0]):
            continue
        t, _ = kendalltau(a[i], b[i])
        if not np.isnan(t):
            taus.append(t)
    return float(np.mean(taus)) if taus else float("nan")


def precision_at_k(phi, parent_idx, k=None):
    """Share of oracle parents among the top-k features (k defaults to |P|)."""
    a = np.abs(phi)
    P = set(parent_idx)
    k = k or len(P)
    if k == 0:
        return float("nan")
    hits = []
    for i in range(a.shape[0]):
        top = set(np.argsort(-a[i])[:k])
        hits.append(len(top & P) / k)
    return float(np.mean(hits))


def bootstrap_ci(values, n_boot=2000, alpha=0.05, seed=0):
    """Bootstrap CI for the mean of a per-instance metric array."""
    rng = np.random.default_rng(seed)
    v = np.asarray(values)
    v = v[~np.isnan(v)]
    if len(v) == 0:
        return (float("nan"), float("nan"))
    boots = [rng.choice(v, len(v), replace=True).mean() for _ in range(n_boot)]
    return float(np.quantile(boots, alpha / 2)), float(np.quantile(boots, 1 - alpha / 2))


def paired_diff_ci(a, b, n_boot=2000, alpha=0.05, seed=0):
    """Paired bootstrap CI for mean(a-b) (e.g. ARCA - SHAP per-instance tau)."""
    rng = np.random.default_rng(seed)
    a, b = np.asarray(a), np.asarray(b)
    m = ~(np.isnan(a) | np.isnan(b))
    d = a[m] - b[m]
    if len(d) == 0:
        return (float("nan"), float("nan"), float("nan"))
    boots = [rng.choice(d, len(d), replace=True).mean() for _ in range(n_boot)]
    return float(d.mean()), float(np.quantile(boots, alpha / 2)), float(np.quantile(boots, 1 - alpha / 2))


# ----------------------------- E2 ---------------------------------------------
def deletion_curve(predict, X, order, background, insertion=False):
    """Mean predicted-class probability as features are removed (or inserted)
    in ``order`` (per-row ranking), replaced by background values."""
    n, d = X.shape
    bg = np.asarray(background).mean(0)
    base = X.copy() if not insertion else np.tile(bg, (n, 1))
    p0 = predict(X)
    curve = [predict(base).mean()]
    cur = base.copy()
    for step in range(d):
        for i in range(n):
            j = order[i, step]
            cur[i, j] = bg[j] if not insertion else X[i, j]
        curve.append(predict(cur).mean())
    return np.asarray(curve)


def normalised_faithfulness(predict, X, phi, phi_star, background, insertion=False):
    """F_del / F_ins normalised so 0 = random ordering, 1 = oracle ordering (Eq 14)."""
    n, d = X.shape
    rng = np.random.default_rng(0)
    order_m = np.argsort(-np.abs(phi), axis=1)
    order_o = np.argsort(-np.abs(phi_star), axis=1)
    order_r = np.stack([rng.permutation(d) for _ in range(n)])
    auc = lambda o: np.trapz(deletion_curve(predict, X, o, background, insertion))
    a_m, a_o, a_r = auc(order_m), auc(order_o), auc(order_r)
    denom = (a_o - a_r)
    if abs(denom) < 1e-9:
        return float("nan")
    return float((a_m - a_r) / denom)


# ----------------------------- E4 ---------------------------------------------
def seed_kendall(global_rankings):
    """Mean pairwise Kendall tau of global rankings across seeds."""
    S = len(global_rankings)
    taus = []
    for i in range(S):
        for j in range(i + 1, S):
            t, _ = kendalltau(global_rankings[i], global_rankings[j])
            if not np.isnan(t):
                taus.append(t)
    return float(np.mean(taus)) if taus else float("nan")


def topk_jaccard(global_rankings, k=5):
    tops = [set(np.argsort(-np.abs(r))[:k]) for r in global_rankings]
    js = []
    for i in range(len(tops)):
        for j in range(i + 1, len(tops)):
            u = tops[i] | tops[j]
            js.append(len(tops[i] & tops[j]) / len(u) if u else 1.0)
    return float(np.mean(js)) if js else float("nan")


def local_lipschitz(explain_fn, X, sigma=0.05, n_pert=10, seed=0):
    """Max ||phi(x)-phi(x')|| / ||x-x'|| over Gaussian neighbours (L1-normalised)."""
    rng = np.random.default_rng(seed)
    phi0 = explain_fn(X)
    phi0 = phi0 / np.clip(np.abs(phi0).sum(1, keepdims=True), 1e-9, None)
    worst = np.zeros(len(X))
    for _ in range(n_pert):
        noise = rng.normal(scale=sigma, size=X.shape)
        phi1 = explain_fn(X + noise)
        phi1 = phi1 / np.clip(np.abs(phi1).sum(1, keepdims=True), 1e-9, None)
        num = np.linalg.norm(phi1 - phi0, axis=1)
        den = np.clip(np.linalg.norm(noise, axis=1), 1e-9, None)
        worst = np.maximum(worst, num / den)
    return float(np.mean(worst))


def redundancy_split_index(phi, class_members):
    """Normalised entropy of credit shares within a duplicated class (Eq 16).
    RSI = 1 is an even split; returns (rsi, first_member_share)."""
    a = np.abs(phi)[:, class_members]
    share = a / np.clip(a.sum(1, keepdims=True), 1e-12, None)
    ent = -(share * np.log(np.clip(share, 1e-12, None))).sum(1)
    rsi = ent / np.log(len(class_members))
    return float(np.nanmean(rsi)), float(np.nanmean(share[:, 0]))


# ----------------------------- E5 ---------------------------------------------
def kendalls_w(rank_matrix):
    """Kendall's coefficient of concordance W over m rankings of n items.
    rank_matrix: (m_raters, n_items) of ranks (1 = best)."""
    R = np.asarray(rank_matrix, dtype=float)
    m, n = R.shape
    Rj = R.sum(0)
    S = ((Rj - Rj.mean()) ** 2).sum()
    return float(12 * S / (m ** 2 * (n ** 3 - n)))
