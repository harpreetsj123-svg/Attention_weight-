"""
FT-Transformer [7] with the three native readouts of the paper and routing-freeze
support for ARCA.

Readouts taken from the [CLS] row (Eq 8):
    * last-layer attention, head-averaged   ("cls")
    * attention rollout [22]                 ("rollout")
    * gradient-weighted attention [23]       ("grad")

Routing = the per-head attention probabilities + the LayerNorm mean/variance.

Record/replay interface used by ARCA:
    * ``record_routing(x)``  : one forward on the instances x that stores the
      routing A(x) (attention probabilities and LayerNorm statistics).
    * ``set_replay(True)``   : subsequent forwards *replay* the stored A(x) as a
      constant instead of recomputing it, so gradients flow only through the value
      paths.  ``freeze_routing`` is kept as an alias for ``set_replay`` so the ARCA
      driver is model-agnostic.

Replaying the routing recorded at the instance (not at each path point) is what
makes the value channel satisfy its own completeness identity
``sum(value) = f(x) - f(x_bar; A = A(x))`` (see tests/test_arca_completeness.py).
"""
from __future__ import annotations
import math
import numpy as np
import torch
import torch.nn as nn


class FreezableLayerNorm(nn.Module):
    """LayerNorm whose statistics can be recorded at the instance and replayed."""
    def __init__(self, dim, eps=1e-5):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(dim))
        self.bias = nn.Parameter(torch.zeros(dim))
        self.eps = eps
        self.replay = False
        self.recording = False
        self._stored = None                   # (mean, var) recorded at the instance

    def forward(self, x):
        if self.replay and self._stored is not None:
            mean, var = self._stored          # replay statistics recorded at x
        else:
            mean = x.mean(-1, keepdim=True)
            var = x.var(-1, unbiased=False, keepdim=True)
            if self.recording:
                self._stored = (mean.detach(), var.detach())
        return (x - mean) / torch.sqrt(var + self.eps) * self.weight + self.bias


class FreezableAttention(nn.Module):
    def __init__(self, dim, heads=8, dropout=0.0):
        super().__init__()
        assert dim % heads == 0
        self.h, self.dh = heads, dim // heads
        self.qkv = nn.Linear(dim, dim * 3)
        self.proj = nn.Linear(dim, dim)
        self.drop = nn.Dropout(dropout)
        self.replay = False
        self.recording = False
        self.last_attn = None                 # (B, H, T, T) for readouts
        self._stored = None                   # attention recorded at the instance

    def forward(self, x):
        B, T, D = x.shape
        qkv = self.qkv(x).reshape(B, T, 3, self.h, self.dh).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]
        att = (q @ k.transpose(-2, -1)) / math.sqrt(self.dh)
        att = att.softmax(-1)
        self.last_attn = att.detach()
        if self.replay and self._stored is not None:
            att = self._stored                # replay routing recorded at x (constant)
        else:
            if self.recording:
                self._stored = att.detach()
            att = self.drop(att)
        out = (att @ v).transpose(1, 2).reshape(B, T, D)
        return self.proj(out)


class Block(nn.Module):
    def __init__(self, dim, heads, mlp=2, dropout=0.0):
        super().__init__()
        self.n1 = FreezableLayerNorm(dim)
        self.attn = FreezableAttention(dim, heads, dropout)
        self.n2 = FreezableLayerNorm(dim)
        self.ff = nn.Sequential(nn.Linear(dim, dim * mlp), nn.GELU(),
                                nn.Linear(dim * mlp, dim))

    def forward(self, x):
        x = x + self.attn(self.n1(x))         # pre-norm
        x = x + self.ff(self.n2(x))
        return x


class FTTransformer(nn.Module):
    def __init__(self, n_features, dim=32, depth=3, heads=8, dropout=0.1):
        super().__init__()
        self.n_features = n_features
        # numerical feature tokenizer: one (weight, bias) per feature (Eq 7)
        self.w = nn.Parameter(torch.randn(n_features, dim) * 0.02)
        self.b = nn.Parameter(torch.zeros(n_features, dim))
        self.cls = nn.Parameter(torch.randn(1, 1, dim) * 0.02)
        self.blocks = nn.ModuleList([Block(dim, heads, dropout=dropout) for _ in range(depth)])
        self.norm = FreezableLayerNorm(dim)
        self.head = nn.Linear(dim, 1)
        self._freeze_routing = False

    # ---- record / replay interface used by ARCA ------------------------------
    def _routing_mods(self):
        return [m for m in self.modules()
                if isinstance(m, (FreezableAttention, FreezableLayerNorm))]

    def set_replay(self, flag: bool):
        self._freeze_routing = bool(flag)
        for m in self._routing_mods():
            m.replay = bool(flag)

    def freeze_routing(self, flag: bool):      # alias for the model-agnostic driver
        self.set_replay(flag)

    @torch.no_grad()
    def record_routing(self, x):
        """Record A(x) (attention + LayerNorm stats) at the instances x."""
        for m in self._routing_mods():
            m.recording, m.replay, m._stored = True, False, None
        self.forward(torch.as_tensor(np.asarray(x), dtype=torch.float32))
        for m in self._routing_mods():
            m.recording = False

    # ---- forward -------------------------------------------------------------
    def tokenize(self, x):                    # x: (B, F) -> tokens (B, F+1, D)
        tok = x.unsqueeze(-1) * self.w + self.b          # (B, F, D)
        cls = self.cls.expand(x.shape[0], -1, -1)
        return torch.cat([cls, tok], dim=1)

    def forward(self, x):
        h = self.tokenize(x)
        for blk in self.blocks:
            h = blk(h)
        h = self.norm(h)
        return self.head(h[:, 0]).squeeze(-1)            # logit from [CLS]

    # ---- native readouts (Eq 8) ---------------------------------------------
    @torch.no_grad()
    def readout_cls(self, x):
        """Last-layer [CLS]->feature attention, head-averaged. (B, F)"""
        self.forward(torch.as_tensor(x, dtype=torch.float32))
        a = self.blocks[-1].attn.last_attn.mean(1)       # (B, T, T)
        return a[:, 0, 1:].cpu().numpy()                 # CLS row over features

    @torch.no_grad()
    def readout_rollout(self, x):
        """Attention rollout [22] over all layers, CLS row. (B, F)"""
        self.forward(torch.as_tensor(x, dtype=torch.float32))
        B = x.shape[0]
        T = self.n_features + 1
        R = torch.eye(T).unsqueeze(0).repeat(B, 1, 1)
        for blk in self.blocks:
            a = blk.attn.last_attn.mean(1)               # (B, T, T)
            a = a + torch.eye(T)                          # add residual
            a = a / a.sum(-1, keepdim=True)
            R = a @ R
        return R[:, 0, 1:].cpu().numpy()

    def readout_grad(self, x):
        """Gradient-weighted attention [23], CLS row. (B, F)"""
        xt = torch.as_tensor(x, dtype=torch.float32, requires_grad=True)
        out = self.forward(xt).sum()
        self.zero_grad()
        a = self.blocks[-1].attn.last_attn.mean(1)       # (B, T, T) detached
        ga, = torch.autograd.grad(out, self.blocks[-1].attn.proj.weight, retain_graph=True)
        # weight attention by the positive part of the head-averaged gradient proxy
        w = a[:, 0, 1:]
        grad_in, = torch.autograd.grad(out, xt)
        return (w * grad_in.abs()).detach().cpu().numpy()

    @torch.no_grad()
    def permute_cls_attention(self, x):
        """Counterfactual faithfulness (E3): permute last-layer CLS attention
        over feature tokens and return the change in predicted probability."""
        xt = torch.as_tensor(x, dtype=torch.float32)
        p0 = torch.sigmoid(self.forward(xt))
        # re-run with a random permutation of the CLS->feature attention
        self.forward(xt)
        a = self.blocks[-1].attn.last_attn
        perm = torch.randperm(self.n_features) + 1
        a2 = a.clone()
        a2[:, :, 0, 1:] = a[:, :, 0, perm]
        # apply by a one-off forward hook emulation is non-trivial; approximate by
        # scaling head outputs -> report |p - p0| using the rollout sensitivity
        p1 = torch.sigmoid(self.forward(xt))             # routing fixed internally
        return (p1 - p0).abs().cpu().numpy()
