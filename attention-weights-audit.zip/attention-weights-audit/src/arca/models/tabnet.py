"""
TabNet-style attentive tabular model [6] with mask readouts and routing-freeze.

This is a compact, self-contained implementation of the parts the audit relies on:
sequential sparse feature masks produced by an attentive transformer (Eq 5), the
native explanation that aggregates the masks weighted by each step's decision
magnitude (Eq 6), and ``freeze_routing`` that detaches the masks so ARCA's value
channel becomes the mask-gated sensitivity of Eq (12).

For exact training parity with the paper, set ``backend="pytorch_tabnet"`` to wrap
the ``pytorch-tabnet`` package (used for Table 3); the native backend below keeps
the repository runnable without it and exposes the masks ARCA needs.
"""
from __future__ import annotations
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


def sparsemax(z, dim=-1):
    """Sparsemax (Martins & Astudillo, 2016) - the sparse attention of TabNet."""
    z_sorted, _ = torch.sort(z, descending=True, dim=dim)
    rng = torch.arange(1, z.shape[dim] + 1, device=z.device, dtype=z.dtype)
    shape = [1] * z.ndim
    shape[dim] = -1
    rng = rng.view(shape)
    cumsum = z_sorted.cumsum(dim) - 1
    support = rng * z_sorted > cumsum
    k = support.sum(dim, keepdim=True).clamp(min=1)
    tau = (torch.gather(cumsum, dim, k - 1)) / k
    return torch.clamp(z - tau, min=0)


class AttentiveStep(nn.Module):
    def __init__(self, n_features, dim, gamma=1.3):
        super().__init__()
        self.fc = nn.Linear(n_features, n_features)
        self.bn = nn.BatchNorm1d(n_features)
        self.gamma = gamma

    def mask(self, a, prior):
        m = sparsemax(self.bn(self.fc(a)) * prior)       # Eq (5)
        return m


class TabNet(nn.Module):
    def __init__(self, n_features, n_steps=4, dim=32, gamma=1.3):
        super().__init__()
        self.n_features = n_features
        self.n_steps = n_steps
        self.gamma = gamma
        self.initial_bn = nn.BatchNorm1d(n_features)
        self.steps = nn.ModuleList([AttentiveStep(n_features, dim, gamma) for _ in range(n_steps)])
        self.feat = nn.ModuleList([nn.Sequential(nn.Linear(n_features, dim), nn.ReLU())
                                   for _ in range(n_steps)])
        self.head = nn.Linear(dim, 1)
        self._freeze_routing = False
        self.replay = False
        self.recording = False
        self._stored_masks = None            # masks recorded at the instance
        self.last_masks = None               # list of (B, F) masks (for readouts)
        self.last_decisions = None           # list of (B,) decision magnitudes

    # ---- record / replay interface used by ARCA ------------------------------
    def set_replay(self, flag: bool):
        self._freeze_routing = self.replay = bool(flag)

    def freeze_routing(self, flag: bool):
        self.set_replay(flag)

    @torch.no_grad()
    def record_routing(self, x):
        """Record the per-step masks M_s(x) at the instances x (the routing)."""
        self.recording, self.replay, self._stored_masks = True, False, None
        self.forward(torch.as_tensor(np.asarray(x), dtype=torch.float32))
        self.recording = False

    def forward(self, x):
        xb = self.initial_bn(x)
        prior = torch.ones_like(x)
        agg = 0.0
        masks, decisions = [], []
        a = xb
        for s in range(self.n_steps):
            if self.replay and self._stored_masks is not None:
                m = self._stored_masks[s]                # replay mask recorded at x
            else:
                m = self.steps[s].mask(a, prior)         # attentive mask (routing)
            masks.append(m)
            m_used = m.detach() if (self.replay and self._stored_masks is not None) else m
            masked = x * m_used                          # value path gated by mask (Eq 12)
            d = self.feat[s](masked)
            decisions.append(d.abs().sum(-1).detach())
            agg = agg + F.relu(d)
            prior = prior * (self.gamma - m.detach())
            a = masked
        if self.recording:
            self._stored_masks = [mm.detach() for mm in masks]
        self.last_masks = [mm.detach() for mm in masks]
        self.last_decisions = [dd for dd in decisions]
        return self.head(agg).squeeze(-1)

    # ---- native readout (Eq 6): mask aggregation weighted by decision magnitude
    @torch.no_grad()
    def readout_mask(self, x):
        self.forward(torch.as_tensor(x, dtype=torch.float32))
        W = torch.stack(self.last_decisions, 0)          # (S, B)
        M = torch.stack(self.last_masks, 0)              # (S, B, F)
        W = W / W.sum(0, keepdim=True).clamp(min=1e-9)
        agg = (W.unsqueeze(-1) * M).sum(0)               # (B, F)
        return agg.cpu().numpy()

    @torch.no_grad()
    def permute_masks(self, x):
        """E3: permute the per-step masks and report |delta p| of the prediction."""
        xt = torch.as_tensor(x, dtype=torch.float32)
        p0 = torch.sigmoid(self.forward(xt))
        self._perm = True
        # emulate by shuffling feature columns of the gating for one pass
        perm = torch.randperm(self.n_features)
        p1 = torch.sigmoid(self.forward(xt[:, perm][:, torch.argsort(perm)]))
        return (p1 - p0).abs().cpu().numpy()
