"""
The five reference models of the paper and a small trainer for the attention nets.

    LR   - L2-regularised logistic regression   (linear SHAP is exact)
    MLP  - multilayer perceptron
    EBM  - explainable boosting machine [33]    (term contributions read directly)
    XGB  - XGBoost [34]                          (interventional TreeSHAP)
    LGBM - LightGBM [35]

If xgboost / lightgbm / interpret are not installed, drop-in scikit-learn
equivalents are used so the pipeline still runs; the canonical libraries (and
versions) are listed in ``requirements.txt`` and used for the reported Table 3.
"""
from __future__ import annotations
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.ensemble import HistGradientBoostingClassifier


def _xgb():
    try:
        from xgboost import XGBClassifier
        return XGBClassifier(n_estimators=300, max_depth=5, learning_rate=0.1,
                             subsample=0.8, eval_metric="logloss", n_jobs=2)
    except Exception:
        return HistGradientBoostingClassifier(max_depth=5, learning_rate=0.1)


def _lgbm():
    try:
        from lightgbm import LGBMClassifier
        return LGBMClassifier(n_estimators=400, num_leaves=31, learning_rate=0.05, n_jobs=2)
    except Exception:
        return HistGradientBoostingClassifier(max_iter=400, learning_rate=0.05)


def _ebm():
    try:
        from interpret.glassbox import ExplainableBoostingClassifier
        return ExplainableBoostingClassifier(interactions=0)
    except Exception:
        return HistGradientBoostingClassifier(max_depth=3)


def build_references(class_weight=None):
    """Return a dict name -> fresh estimator."""
    return {
        "LR": LogisticRegression(C=1.0, max_iter=2000, class_weight=class_weight),
        "MLP": MLPClassifier(hidden_layer_sizes=(128, 64), max_iter=300, early_stopping=True),
        "EBM": _ebm(),
        "XGBoost": _xgb(),
        "LightGBM": _lgbm(),
    }


# --------------------------------------------------------------------------- #
#  Trainer for the two attention networks (class-weighted BCE, early stopping) #
# --------------------------------------------------------------------------- #
def train_torch(model, Xtr, ytr, Xva, yva, epochs=60, lr=1e-3, wd=1e-5,
                batch=1024, patience=8, pos_weight=None, opt="adamw", seed=0):
    import torch
    torch.manual_seed(seed)
    Xtr = torch.as_tensor(np.asarray(Xtr), dtype=torch.float32)
    ytr = torch.as_tensor(np.asarray(ytr), dtype=torch.float32)
    Xva = torch.as_tensor(np.asarray(Xva), dtype=torch.float32)
    if pos_weight is None:
        pos_weight = (ytr == 0).sum() / max((ytr == 1).sum(), 1)
    pw = torch.tensor(float(pos_weight))
    loss_fn = torch.nn.BCEWithLogitsLoss(pos_weight=pw)
    Opt = torch.optim.AdamW if opt == "adamw" else torch.optim.Adam
    optim = Opt(model.parameters(), lr=lr, weight_decay=wd)

    from sklearn.metrics import average_precision_score
    best, best_state, bad, history = -1.0, None, 0, []
    n = Xtr.shape[0]
    for ep in range(epochs):
        model.train()
        perm = torch.randperm(n)
        ep_loss = 0.0
        for i in range(0, n, batch):
            idx = perm[i:i + batch]
            optim.zero_grad()
            out = model(Xtr[idx])
            loss = loss_fn(out, ytr[idx])
            loss.backward()
            optim.step()
            ep_loss += float(loss) * len(idx)
        model.eval()
        with torch.no_grad():
            pv = torch.sigmoid(model(Xva)).cpu().numpy()
        ap = average_precision_score(yva, pv)
        history.append({"epoch": ep, "val_auprc": float(ap), "train_loss": ep_loss / n})
        if ap > best:
            best, best_state, bad = ap, {k: v.clone() for k, v in model.state_dict().items()}, 0
        else:
            bad += 1
            if bad >= patience:
                break
    if best_state is not None:
        model.load_state_dict(best_state)
    return model, history
