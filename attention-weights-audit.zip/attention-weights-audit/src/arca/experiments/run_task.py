"""
Run one task end to end: train models, recover the oracle, compute every
explainer, evaluate the E1-E5 protocol and write per-instance / summary outputs.

By default it uses the synthetic regime generators so it runs without any data
download; pass ``--real`` to use the Kaggle loaders instead.  The attention
networks and ARCA require PyTorch; if torch is absent the reference models,
oracle, SHAP and metrics still run (and the nets are skipped with a warning).

Usage:
    python -m arca.experiments.run_task --task T1 --out results/runs/T1
"""
from __future__ import annotations
import argparse
import json
import os
import time
import warnings
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import average_precision_score, roc_auc_score

from ..data import build
from ..models import build_references, train_torch, FTTransformer, TabNet
from ..attributions import (arca, oracle_for, perm_shap_fast, linear_shap,
                            tree_shap, ft_readouts, tabnet_readout)
from ..evaluation import mean_kendall, precision_at_k, paired_diff_ci


def _logit_fn(clf):
    def f(Z):
        p = np.clip(clf.predict_proba(Z)[:, 1], 1e-6, 1 - 1e-6)
        return np.log(p / (1 - p))
    return f


def run(task="T1", n=6000, n_explain=200, seed=0, out=None, use_torch=True):
    rng = np.random.default_rng(seed)
    reg = build(task, seed=seed) if task in ("T1", "T3", "T4", "T5") else build(task)
    X, y = reg.X.astype(np.float32), reg.y
    strat = y if reg.groups is None else None
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.3, random_state=seed, stratify=strat)
    Xtr, Xva, ytr, yva = train_test_split(Xtr, ytr, test_size=0.2, random_state=seed,
                                          stratify=ytr if reg.groups is None else None)
    # explained instances
    idx = rng.choice(len(Xte), size=min(n_explain, len(Xte)), replace=False)
    Xex = Xte[idx]

    # ---- oracle ----
    phi_star, oinfo = oracle_for(reg, Xex)
    parents = reg.parent_idx

    perf, attribs = {}, {}

    # ---- reference models ----
    refs = build_references(class_weight="balanced")
    bg = Xtr[rng.choice(len(Xtr), size=min(50, len(Xtr)), replace=False)]
    for name, clf in refs.items():
        clf.fit(Xtr, ytr)
        p = clf.predict_proba(Xte)[:, 1]
        perf[name] = {"AUPRC": float(average_precision_score(yte, p)),
                      "AUROC": float(roc_auc_score(yte, p))}
        if name == "LR":
            attribs["LR SHAP (exact)"] = np.abs(linear_shap(clf, Xex, bg))
        elif name == "XGBoost":
            attribs["XGBoost TreeSHAP"] = np.abs(tree_shap(clf, Xex))

    # ---- attention networks + ARCA ----
    torch_ok = False
    if use_torch and FTTransformer is not None:
        try:
            import torch  # noqa
            torch_ok = True
        except Exception:
            torch_ok = False
    if torch_ok:
        d = X.shape[1]
        ft = FTTransformer(d, dim=32, depth=3, heads=8)
        ft, hist_ft = train_torch(ft, Xtr, ytr, Xva, yva, opt="adamw", seed=seed)
        import torch
        with torch.no_grad():
            pft = torch.sigmoid(ft(torch.as_tensor(Xte))).numpy()
        perf["FT-T"] = {"AUPRC": float(average_precision_score(yte, pft)),
                        "AUROC": float(roc_auc_score(yte, pft))}
        attribs.update(ft_readouts(ft, Xex))
        res = arca(ft, Xex, background=bg, m=8)
        attribs["FT-T ARCA"] = np.abs(res.total)
        attribs["FT-T ARCA-V"] = np.abs(res.value)
        f_ft = lambda Z: ft(torch.as_tensor(Z, dtype=torch.float32)).detach().numpy()
        attribs["FT-T SHAP"] = np.abs(perm_shap_fast(f_ft, Xex, bg, n_perm=6))

        tn = TabNet(d, n_steps=4, dim=32)
        tn, hist_tn = train_torch(tn, Xtr, ytr, Xva, yva, opt="adam", seed=seed)
        with torch.no_grad():
            ptn = torch.sigmoid(tn(torch.as_tensor(Xte))).numpy()
        perf["TabNet"] = {"AUPRC": float(average_precision_score(yte, ptn)),
                          "AUROC": float(roc_auc_score(yte, ptn))}
        attribs.update(tabnet_readout(tn, Xex))
        res_tn = arca(tn, Xex, background=bg, m=8)
        attribs["TabNet ARCA"] = np.abs(res_tn.total)
        attribs["TabNet ARCA-V"] = np.abs(res_tn.value)
        f_tn = lambda Z: tn(torch.as_tensor(Z, dtype=torch.float32)).detach().numpy()
        attribs["TabNet SHAP"] = np.abs(perm_shap_fast(f_tn, Xex, bg, n_perm=6))
    else:
        warnings.warn("PyTorch not available: skipping FT-Transformer, TabNet and ARCA.")

    # ---- E1 oracle agreement ----
    rows = []
    for name, phi in attribs.items():
        tau = mean_kendall(phi, phi_star)
        pat = precision_at_k(phi, parents) if parents else float("nan")
        rows.append({"explainer": name, "tau": tau, "precision": pat})
    agree = pd.DataFrame(rows)

    # paired ARCA vs SHAP CI (FT-T), if available
    paired = {}
    if "FT-T ARCA" in attribs and "FT-T SHAP" in attribs:
        ta = [mean_kendall(attribs["FT-T ARCA"][i:i + 1], phi_star[i:i + 1])
              for i in range(len(Xex))]
        ts = [mean_kendall(attribs["FT-T SHAP"][i:i + 1], phi_star[i:i + 1])
              for i in range(len(Xex))]
        paired["FT-T ARCA-SHAP"] = paired_diff_ci(np.array(ta), np.array(ts))

    result = {"task": task, "regime": reg.regime, "oracle": oinfo,
              "performance": perf, "agreement": agree.to_dict("records"),
              "paired_ci": paired, "n_explain": len(Xex), "torch": torch_ok}

    if out:
        os.makedirs(out, exist_ok=True)
        agree.to_csv(os.path.join(out, f"{task}_agreement.csv"), index=False)
        pd.DataFrame(perf).T.to_csv(os.path.join(out, f"{task}_performance.csv"))
        with open(os.path.join(out, f"{task}_summary.json"), "w") as f:
            json.dump(result, f, indent=2, default=float)
    return result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--task", default="T1", choices=["T1", "T3", "T4", "T5"])
    ap.add_argument("--n", type=int, default=6000)
    ap.add_argument("--n-explain", type=int, default=200)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", default=None)
    ap.add_argument("--no-torch", action="store_true")
    a = ap.parse_args()
    res = run(a.task, a.n, a.n_explain, a.seed, a.out, use_torch=not a.no_torch)
    print(json.dumps({"task": res["task"], "regime": res["regime"],
                      "performance": res["performance"]}, indent=2, default=float))
    print("\nOracle agreement (Kendall tau):")
    for r in res["agreement"]:
        print(f"  {r['explainer']:24s} tau={r['tau']:.3f}  P@|P|={r['precision']}")


if __name__ == "__main__":
    main()
