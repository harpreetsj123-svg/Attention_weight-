"""
Run every task and assemble the result tables, then regenerate the figures.

    python -m arca.experiments.run_all --out results/runs

With ``--reported`` it skips computation and simply regenerates Tables 3-5 and
Figures 2-3 from the published values in ``results/reported`` (the default demo).
"""
from __future__ import annotations
import argparse
import os
import pandas as pd
from . import run_task
from ..figures import make_tables, make_figures

TASKS = ["T1", "T3", "T4", "T5"]


def main():
    ap = argparse.ArgumentParser()
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
    ap.add_argument("--out", default=os.path.join(root, "results", "runs"))
    ap.add_argument("--reported", action="store_true",
                    help="regenerate tables/figures from published values only")
    ap.add_argument("--no-torch", action="store_true")
    ap.add_argument("--n", type=int, default=6000)
    ap.add_argument("--n-explain", type=int, default=200)
    a = ap.parse_args()

    if not a.reported:
        os.makedirs(a.out, exist_ok=True)
        allrows = []
        for t in TASKS:
            print(f"=== {t} ===")
            res = run_task.run(t, a.n, a.n_explain, out=a.out, use_torch=not a.no_torch)
            for r in res["agreement"]:
                r["task"] = t
                allrows.append(r)
        pd.DataFrame(allrows).to_csv(os.path.join(a.out, "oracle_agreement_all.csv"), index=False)
        print("per-task outputs in", a.out)

    rep = os.path.join(root, "results", "reported")
    make_tables.table3(rep, os.path.join(root, "results", "tables"))
    make_tables.table4(rep, os.path.join(root, "results", "tables"))
    make_tables.table5(rep, os.path.join(root, "results", "tables"))
    make_figures.fig2(rep, os.path.join(root, "results", "figures"))
    make_figures.fig3(rep, os.path.join(root, "results", "figures"))
    print("tables -> results/tables, figures -> results/figures")


if __name__ == "__main__":
    main()
