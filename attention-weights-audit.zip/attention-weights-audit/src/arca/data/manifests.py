"""
Leakage-exclusion manifests for the three public datasets (Table 2 of the paper).

Each entry lists the fields removed *before any split* together with the reason,
so the generator-recovery and split-separation claims can be audited.  The real
preprocessing in ``loaders.py`` consumes these manifests; they are kept as plain
data here so they can be inspected and version-controlled.
"""
from __future__ import annotations

MANIFESTS = {
    "D1": {
        "source": "Mental Health & Burnout in Tech Workers 2026 (Kaggle, CC0)",
        "exclude": {
            "burnout_score": "label source (defines T1 target)",
            "burnout_level": "label (ordinal form of target)",
            "stress_level": "co-measured with burnout score",
            "phq9_depression": "co-measured psychometric score",
            "gad7_anxiety": "co-measured psychometric score",
        },
        "note": "Co-measured scores retained only in the T2 sensitivity arm.",
    },
    "D2": {
        "source": "Employee Burnout & Turnover Prediction (Kaggle, CC BY-NC-ND 4.0)",
        "exclude": {
            "stress_level": "rho = 1.00 with burnout_risk",
            "risk_summary": "label-derived text summary",
            "turnover_reason": "99.6% agreement with left_company (T4 label)",
            "persona": "generator metadata",
            "free_text": "generator metadata",
            "role_text": "generator metadata",
            "employee_id": "identifier",
            "p_gen": "kept out of features; retained as oracle/ceiling only",
        },
        "duplicates": {
            "slack_activity": "== collaboration_score",
            "meeting_participation": "== collaboration_score",
            "goal_achievement_rate": "== performance_score",
            "email_sentiment": "~ satisfaction_score (r = 0.9986)",
        },
        "note": "Duplicates kept only in the redundancy arm; manipulated as groups.",
    },
    "D3": {
        "source": "Work From Home Employee Burnout (Kaggle, CC0)",
        "exclude": {
            "burnout_score": "label source (defines T5 target)",
            "risk_band": "label (binned target)",
        },
        "note": "Ten-day panel of 180 users; split by user.",
    },
}

LEAKAGE_DEMO = {
    # AUROC with vs without re-including an excluded field (Section 3.2)
    "T1": {"audited": 0.923, "with_leak": 0.974, "field": "stress/PHQ-9/GAD-7"},
    "T4": {"audited": 0.572, "with_leak": 1.000, "field": "turnover_reason"},
}
