"""
Loaders for the three real Kaggle datasets.

Download the datasets (see README) into ``data/raw/`` and these functions apply
the leakage-exclusion manifests of :mod:`arca.data.manifests`, build the task
labels described in Table 2, and return a :class:`arca.data.generators.Regime`
bundle with the *same interface* as the synthetic generators, so the rest of the
pipeline is unchanged.

Because D2 is licensed CC BY-NC-ND 4.0 it is neither redistributed nor cached;
only its preparation script (this file) is released.
"""
from __future__ import annotations
import os
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from .manifests import MANIFESTS
from .generators import Regime

RAW = os.environ.get("ARCA_DATA", "data/raw")


def _encode(df: pd.DataFrame, cat_cols):
    num = df.drop(columns=cat_cols)
    scaler = StandardScaler().fit(num.values)
    Xn = scaler.transform(num.values)
    names = list(num.columns)
    if cat_cols:
        enc = OneHotEncoder(handle_unknown="ignore", sparse_output=False).fit(df[cat_cols])
        Xc = enc.transform(df[cat_cols])
        names += list(enc.get_feature_names_out(cat_cols))
        X = np.hstack([Xn, Xc])
    else:
        X = Xn
    return X.astype(np.float32), names


def load_T1(path=None) -> Regime:
    """D1 burnout: label burnout_score >= 7.1 (prev ~28.6%)."""
    path = path or os.path.join(RAW, "d1_tech_burnout_2026.csv")
    df = pd.read_csv(path)
    y = (df["burnout_score"] >= 7.1).astype(int).values
    df = df.drop(columns=[c for c in MANIFESTS["D1"]["exclude"] if c in df])
    cat = [c for c in df.columns if df[c].dtype == object]
    X, names = _encode(df, cat)
    return Regime("T1", "R1", X, y, names, y.astype(float), parents=[])


def load_T3(path=None, n_model=100_000) -> Regime:
    """D2 burnout_risk >= 0.90 (prev ~50.8%); saturating regime."""
    path = path or os.path.join(RAW, "d2_burnout_turnover_800k.json")
    df = pd.read_json(path, lines=True) if path.endswith(".json") else pd.read_csv(path)
    df = df.sample(n=min(n_model, len(df)), random_state=0).reset_index(drop=True)
    y = (df["burnout_risk"] >= 0.90).astype(int).values
    df = df.drop(columns=[c for c in MANIFESTS["D2"]["exclude"] if c in df])
    cat = [c for c in df.columns if df[c].dtype == object]
    X, names = _encode(df, cat)
    return Regime("T3", "R2", X, y, names, y.astype(float), parents=[])


def load_T5(path=None) -> Regime:
    """D3 WFH burnout: burnout_score >= 70 (prev ~15.2%); split by user."""
    path = path or os.path.join(RAW, "d3_wfh_burnout.csv")
    df = pd.read_csv(path)
    y = (df["burnout_score"] >= 70).astype(int).values
    groups = df["user_id"].astype("category").cat.codes.values if "user_id" in df else None
    df = df.drop(columns=[c for c in list(MANIFESTS["D3"]["exclude"]) + ["user_id"] if c in df])
    cat = [c for c in df.columns if df[c].dtype == object]
    X, names = _encode(df, cat)
    return Regime("T5", "R4", X, y, names, y.astype(float), parents=[], groups=groups)


REAL_LOADERS = {"T1": load_T1, "T3": load_T3, "T5": load_T5}
