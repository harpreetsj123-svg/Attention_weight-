"""
Synthetic generators for the four data-generating regimes of the paper.

These reproduce the *structure* of the three public Kaggle datasets so that the
whole pipeline (training -> attribution -> evaluation -> tables/figures) runs
end to end without downloading any data.  Pointing ``loaders.py`` at the real
Kaggle files reproduces the reported numbers; the generators below reproduce the
regimes:

    R1 (T1)  additive burnout score            (linear oracle, R^2 ~ 0.71)
    R2 (T3)  saturating score from redundancy   (GB surrogate oracle, R^2 ~ 1.0)
    R3 (T4)  noise-limited attrition            (Bernoulli(p_gen), ceiling)
    R4 (T5)  single-driver repeated-measures    (near-linear in one feature)

Each generator returns a :class:`Regime` bundle carrying the design matrix,
the latent score, the binary label, the names of the oracle "parent" features
and, where applicable, the generating probability ``p_gen`` and group ids.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional
import numpy as np


def _sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-x))


@dataclass
class Regime:
    name: str
    regime: str                      # 'R1'..'R4'
    X: np.ndarray                    # (n, d) standardized features
    y: np.ndarray                    # (n,) binary label
    feature_names: List[str]
    latent: np.ndarray               # (n,) latent generating score
    parents: List[str]               # oracle parent feature names
    p_gen: Optional[np.ndarray] = None
    groups: Optional[np.ndarray] = None
    duplicate_classes: dict = field(default_factory=dict)  # class -> [member names]

    @property
    def parent_idx(self) -> List[int]:
        return [self.feature_names.index(p) for p in self.parents]


def make_R1(n: int = 8000, seed: int = 0) -> Regime:
    """Additive burnout score (mirrors T1 / D1). ~26 features, ~5 true drivers."""
    rng = np.random.default_rng(seed)
    d = 26
    names = [f"f{i:02d}" for i in range(d)]
    X = rng.standard_normal((n, d))
    parents = names[:5]
    w = np.array([1.3, -1.0, 0.9, 0.8, -0.7])
    latent = X[:, :5] @ w + 0.9 * rng.standard_normal(n)   # additive + noise
    thr = np.quantile(latent, 0.714)                        # ~28.6% prevalence
    y = (latent >= thr).astype(int)
    return Regime("T1", "R1", X, y, names, latent, parents)


def make_R2(n: int = 8000, seed: int = 1) -> Regime:
    """Saturating score from four parents + three duplicated classes (T3 / D2)."""
    rng = np.random.default_rng(seed)
    base = ["satisfaction", "workload", "project_completion", "performance"]
    extra = [f"g{i:02d}" for i in range(8)]
    names = base + extra + ["collab", "slack", "meeting"]    # slack/meeting dup collab
    d = len(names)
    X = rng.standard_normal((n, d))
    # duplicate class: slack_activity == meeting_participation == collaboration_score
    ci, si, mi = names.index("collab"), names.index("slack"), names.index("meeting")
    X[:, si] = X[:, ci]
    X[:, mi] = X[:, ci]
    s, wl, pc, pf = (X[:, names.index(b)] for b in base)
    # saturating (logistic) combination -> near-deterministic burnout_risk
    z = 1.6 * (-s) + 1.4 * wl - 1.1 * pc - 0.9 * pf
    risk = _sigmoid(z)
    latent = risk
    y = (risk >= np.quantile(risk, 0.492)).astype(int)       # ~50.8% prevalence
    dup = {"collaboration": ["collab", "slack", "meeting"]}
    return Regime("T3", "R2", X, y, names, latent, base, duplicate_classes=dup)


def make_R3(n: int = 8000, seed: int = 2) -> Regime:
    """Noise-limited attrition: label is Bernoulli(p_gen); p_gen weakly identifiable."""
    rng = np.random.default_rng(seed)
    d = 15
    names = [f"a{i:02d}" for i in range(d)]
    X = rng.standard_normal((n, d))
    parents = names[:4]
    w = np.array([0.45, -0.35, 0.3, -0.25])
    lin = X[:, :4] @ w
    p_gen = _sigmoid(0.6 * lin - 0.92)                       # mean ~ 0.285
    y = (rng.random(n) < p_gen).astype(int)                  # Bernoulli draw
    return Regime("T4", "R3", X, y, names, p_gen, parents, p_gen=p_gen)


def make_R4(n: int = 1800, n_users: int = 180, seed: int = 3) -> Regime:
    """Single-driver repeated-measures panel (T5 / D3): score ~ linear in one feature."""
    rng = np.random.default_rng(seed)
    d = 8
    names = ["task_completion"] + [f"d{i:02d}" for i in range(d - 1)]
    users = np.repeat(np.arange(n_users), n // n_users)
    if users.shape[0] < n:                                   # pad last user
        users = np.concatenate([users, np.full(n - users.shape[0], n_users - 1)])
    X = rng.standard_normal((n, d))
    tc = X[:, 0]
    latent = -1.53 * tc + 0.12 * rng.standard_normal(n)      # slope -1.53, R^2 ~ 0.92
    y = (latent >= np.quantile(latent, 0.848)).astype(int)   # ~15.2% prevalence
    return Regime("T5", "R4", X, y, names, latent, ["task_completion"], groups=users)


ALL_REGIMES = {"R1": make_R1, "R2": make_R2, "R3": make_R3, "R4": make_R4}
TASK_TO_REGIME = {"T1": "R1", "T3": "R2", "T4": "R3", "T5": "R4"}


def build(task_or_regime: str, **kw) -> Regime:
    key = TASK_TO_REGIME.get(task_or_regime, task_or_regime)
    if key not in ALL_REGIMES:
        raise KeyError(f"unknown task/regime {task_or_regime!r}")
    return ALL_REGIMES[key](**kw)
