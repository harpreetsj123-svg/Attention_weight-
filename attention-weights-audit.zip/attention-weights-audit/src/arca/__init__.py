"""
ARCA: Attention-Routed Contrastive Attribution.

Reference implementation for the paper

    "Are Attention Weights Explanations? A Ground-Truth-Anchored Faithfulness
     and Stability Audit of Tabular Attention Models for Employee Burnout and
     Turnover Risk"

The package provides:
  * data        - synthetic regime generators (R1-R4) and Kaggle loaders/manifests
  * models      - FT-Transformer, TabNet wrapper and five reference models
  * attributions- ARCA (value/routing decomposition), SHAP estimators,
                  attention readouts and oracle attributions
  * evaluation  - the E1-E5 protocol (oracle agreement, deletion/insertion,
                  counterfactual faithfulness, stability, replication)
  * figures     - scripts that regenerate Tables 3-5 and Figures 2-3
"""
__version__ = "1.0.0"
