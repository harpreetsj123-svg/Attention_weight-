"""
Regenerate Tables 3, 4 and 5 from ``results/reported`` (or from freshly computed
results placed there by the experiment runner).

Outputs, per table, into ``results/tables``:
    tableN.csv    - tidy values
    tableN.tex    - LaTeX (booktabs) ready to input
    tableN.png    - rendered preview

Usage:  python -m arca.figures.make_tables  [--reported DIR] [--out DIR]
"""
from __future__ import annotations
import argparse
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

MODELS = ["LR", "MLP", "EBM", "XGBoost", "LightGBM", "TabNet", "FT-T"]


def _png_table(df, path, title, fontsize=8, colw=None, bold_mask=None, figw=None):
    n, m = df.shape
    figw = figw or min(2.2 + 0.95 * m, 18)
    fig, ax = plt.subplots(figsize=(figw, 0.45 * n + 0.9))
    ax.axis("off")
    ax.set_title(title, fontsize=fontsize + 2, pad=10, loc="left", fontweight="bold")
    tbl = ax.table(cellText=df.values, colLabels=df.columns, loc="center",
                   cellLoc="center")
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(fontsize)
    tbl.scale(1, 1.25)
    for (r, c), cell in tbl.get_celld().items():
        cell.set_edgecolor("#cccccc")
        if r == 0:
            cell.set_facecolor("#20303f")
            cell.set_text_props(color="white", fontweight="bold")
        elif r % 2 == 0:
            cell.set_facecolor("#f4f6f8")
        if bold_mask is not None and r > 0 and (r - 1, c) in bold_mask:
            cell.set_text_props(fontweight="bold")
    fig.tight_layout()
    fig.savefig(path, dpi=200, bbox_inches="tight")
    plt.close(fig)


def table3(reported, out):
    means = pd.read_csv(os.path.join(reported, "table3_means.csv"))
    ci = pd.read_csv(os.path.join(reported, "table3_ci.csv"))
    rows, bold = [], set()
    for ri, mrow in means.iterrows():
        crow = ci[(ci.task == mrow.task) & (ci.metric == mrow.metric)].iloc[0]
        cells = [f"{mrow.task} {mrow.metric}"]
        vals = [mrow[mm] for mm in MODELS]
        best = np.nanmax(vals)
        for mm in MODELS:
            v = mrow[mm]
            cells.append(f"{v:.3f}±{crow[mm]:.3f}")
            if abs(v - best) < 1e-9:
                bold.add((ri, 1 + MODELS.index(mm)))
        orc = mrow["Oracle_obs"]
        cells.append("–" if pd.isna(orc) else f"{orc:.3f} / {mrow['Oracle_pgen']:.3f}")
        rows.append(cells)
    df = pd.DataFrame(rows, columns=["Task / metric"] + MODELS + ["Oracle"])
    df.to_csv(os.path.join(out, "table3.csv"), index=False)
    _latex(df, os.path.join(out, "table3.tex"),
           "Predictive performance (mean $\\pm$ 95\\% CI half-width over outer folds; "
           "best per row in bold). Oracle: observable surrogate / $p_{gen}$. T3 omitted (ceiling).",
           "tab:perf")
    _png_table(df, os.path.join(out, "table3.png"),
               "Table 3. Predictive performance (best per row in bold)", bold_mask=bold)
    return df


def table4(reported, out):
    df = pd.read_csv(os.path.join(reported, "table4.csv"))
    pretty = df.copy()
    hdr = ["Explainer",
           "T1 τ", "T1 P", "T1 Fdel", "T3 τ", "T3 P", "T3 Fdel",
           "T4 τ", "T4 P", "T4 Fdel", "T5 τ", "T5 P", "T5 Fdel", "Cost ms"]
    pretty.columns = hdr
    # bold best tau and precision per regime column
    bold = set()
    for col in ["T1 τ", "T3 τ", "T4 τ", "T5 τ", "T1 P", "T3 P", "T4 P", "T5 P"]:
        ci = hdr.index(col)
        best = pretty[col].max()
        for ri in pretty.index[np.isclose(pretty[col].values, best)]:
            bold.add((ri, ci))
    for c in hdr[1:-1]:
        pretty[c] = pretty[c].map(lambda v: f"{v:.2f}")
    pretty["Cost ms"] = df["cost_ms"].map(lambda v: f"{v:g}")
    pretty.to_csv(os.path.join(out, "table4.csv"), index=False)
    _latex(pretty, os.path.join(out, "table4.tex"),
           "Oracle agreement (Kendall $\\tau$, precision@$|P|$), deletion faithfulness "
           "$F_{del}$ (1 = oracle) and mean cost per instance. ARCA-V: value channel of ARCA; "
           "bold: best $\\tau$ and precision.", "tab:oracle")
    _png_table(pretty, os.path.join(out, "table4.png"),
               "Table 4. Oracle agreement, faithfulness and cost (best τ/precision in bold)",
               fontsize=7, bold_mask=bold, figw=16)
    return pretty


def table5(reported, out):
    df = pd.read_csv(os.path.join(reported, "table5.csv"))
    pretty = pd.DataFrame({
        "Explainer": df.explainer,
        "Seed τ R4": df.seedtau_R4.map("{:.2f}".format),
        "Seed τ R2": df.seedtau_R2.map("{:.2f}".format),
        "Jacc R4": df.jac_R4.map("{:.2f}".format),
        "Jacc R2": df.jac_R2.map("{:.2f}".format),
        "Lipschitz": df.lipschitz.map("{:.2f}".format),
        "RSI perf (SD)": [f"{a:.2f} ({b:.2f})" for a, b in zip(df.rsi_perf, df.rsi_perf_sd)],
        "RSI sat (SD)": [f"{a:.2f} ({b:.2f})" for a, b in zip(df.rsi_sat, df.rsi_sat_sd)],
        "Class τ R2": df.classtau_R2.map("{:.2f}".format),
    })
    pretty.to_csv(os.path.join(out, "table5.csv"), index=False)
    _latex(pretty, os.path.join(out, "table5.tex"),
           "Seed stability (Kendall $\\tau$ of global rankings, top-5 Jaccard), Lipschitz "
           "estimate, Redundancy-Split Index with the seed SD of the first copy's share, and "
           "class $\\tau$ (duplicates pooled); R2: T3 redundancy arm, R4: T5.", "tab:stability")
    _png_table(pretty, os.path.join(out, "table5.png"),
               "Table 5. Seed stability, Lipschitz, Redundancy-Split Index", fontsize=7, figw=15)
    return pretty


def _latex(df, path, caption, label):
    cols = "l" + "c" * (df.shape[1] - 1)
    lines = ["\\begin{table*}[t]", "\\centering", "\\small",
             f"\\caption{{{caption}}}", f"\\label{{{label}}}",
             f"\\begin{{tabular}}{{{cols}}}", "\\toprule",
             " & ".join(str(c) for c in df.columns) + " \\\\", "\\midrule"]
    for _, r in df.iterrows():
        lines.append(" & ".join(str(v) for v in r.values) + " \\\\")
    lines += ["\\bottomrule", "\\end{tabular}", "\\end{table*}"]
    with open(path, "w") as f:
        f.write("\n".join(lines))


def main():
    ap = argparse.ArgumentParser()
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
    ap.add_argument("--reported", default=os.path.join(root, "results", "reported"))
    ap.add_argument("--out", default=os.path.join(root, "results", "tables"))
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    table3(a.reported, a.out)
    table4(a.reported, a.out)
    table5(a.reported, a.out)
    print("tables written to", a.out)


if __name__ == "__main__":
    main()
