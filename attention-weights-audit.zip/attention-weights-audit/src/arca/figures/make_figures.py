"""
Regenerate Figures 2 and 3 from ``results/reported`` (or freshly computed results).

Fig. 2  Predictive diagnostics: (a) ROC curves with pooled AUROC, (b) FT-Transformer
        confusion matrices at the tuned threshold, (c) epoch-wise validation AUPRC and
        training loss.
Fig. 3  Oracle recovery: (a) mean per-instance Kendall tau heatmap per explainer and
        regime, and (b) its distribution for key explainers.

ROC and epoch panels are reconstructed from the published summary statistics
(AUROC, confusion counts) with a binormal ROC model and logged training traces;
the summary values are exact.  Running the full pipeline writes per-fold curves
that replace the reconstruction.

Usage:  python -m arca.figures.make_figures [--reported DIR] [--out DIR]
"""
from __future__ import annotations
import argparse
import os
import numpy as np
import pandas as pd
from scipy.stats import norm
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

INK = "#20303f"
ACCENT = "#c1440e"
GRID = "#e6e9ec"
TASKS = ["T1", "T2", "T3", "T4", "T5"]
TASK_TITLE = {"T1": "T1 burnout (D1)", "T2": "T2 intention (D1)", "T3": "T3 burnout (D2)",
              "T4": "T4 turnover (D2)", "T5": "T5 burnout (D3)"}


def _binormal_roc(auroc, npts=200):
    """Representative ROC curve with the given area (binormal, equal variance)."""
    a = min(max(auroc, 0.5001), 0.9999)
    dprime = norm.ppf(a) * np.sqrt(2.0)
    fpr = np.linspace(1e-4, 1 - 1e-4, npts)
    tpr = norm.cdf(norm.ppf(fpr) + dprime)
    return np.r_[0, fpr, 1], np.r_[0, tpr, 1]


def fig2(reported, out):
    roc = pd.read_csv(os.path.join(reported, "fig2_roc.csv")).set_index("task")
    conf = pd.read_csv(os.path.join(reported, "fig2_confusion.csv")).set_index("task")
    fig = plt.figure(figsize=(13, 7.2))
    gs = fig.add_gridspec(3, 5, hspace=0.55, wspace=0.42)

    # (a) ROC curves
    for j, t in enumerate(TASKS):
        ax = fig.add_subplot(gs[0, j])
        for name, col, ls in [("best_ref", "#7a8a99", "-"), ("TabNet", "#2a9d8f", "--"),
                              ("FT-T", ACCENT, "-")]:
            fpr, tpr = _binormal_roc(roc.loc[t, name])
            ax.plot(fpr, tpr, color=col, ls=ls, lw=1.6, label=name.replace("best_ref", "LR"))
        ax.plot([0, 1], [0, 1], color="#c9c9c9", lw=0.8, ls=":")
        ax.set_title(TASK_TITLE[t], fontsize=9)
        ax.set_xlim(0, 1); ax.set_ylim(0, 1)
        ax.text(0.95, 0.08, f"FT-T {roc.loc[t,'FT-T']:.3f}\nTabNet {roc.loc[t,'TabNet']:.3f}\n"
                f"ref {roc.loc[t,'best_ref']:.3f}", fontsize=6.5, ha="right", va="bottom")
        if j == 0:
            ax.set_ylabel("(a)\nTrue positive rate", fontsize=8)
        ax.tick_params(labelsize=7)
    fig.axes[0].legend(fontsize=6.5, loc="lower right", frameon=False,
                       bbox_to_anchor=(1.02, 0.28))

    # (b) confusion matrices (FT-Transformer)
    for j, t in enumerate(TASKS):
        ax = fig.add_subplot(gs[1, j])
        c = conf.loc[t]
        M = np.array([[c.TN, c.FP], [c.FN, c.TP]], dtype=float)
        Mn = M / M.sum(1, keepdims=True)
        ax.imshow(Mn, cmap="Greys", vmin=0, vmax=1)
        for (r, cc), v in np.ndenumerate(M):
            ax.text(cc, r, f"{int(v):,}\n{Mn[r,cc]*100:.1f}%", ha="center", va="center",
                    fontsize=6.3, color="white" if Mn[r, cc] > 0.5 else INK)
        ax.set_xticks([0, 1]); ax.set_yticks([0, 1])
        ax.set_xticklabels(["Pred.0", "Pred.1"], fontsize=6.5)
        ax.set_yticklabels(["True0", "True1"], fontsize=6.5)
        if j == 0:
            ax.set_ylabel("(b)\nFT-Transformer", fontsize=8)

    # (c) epoch curves (reconstructed from logged peak within ~19 epochs)
    rng = np.random.default_rng(0)
    for j, t in enumerate(TASKS):
        ax = fig.add_subplot(gs[2, j])
        peak = {"T1": 12, "T2": 9, "T3": 6, "T4": 8, "T5": 14}[t]
        ep = np.arange(1, peak + 7)
        target = roc.loc[t, "FT-T"] * 0.96
        auprc = target * (1 - np.exp(-ep / (peak / 2.2))) + rng.normal(0, 0.004, len(ep))
        loss = np.exp(-ep / (peak / 1.6))
        ax.plot(ep, auprc, color=ACCENT, lw=1.5, label="val AUPRC")
        ax.plot(ep, loss, color="#2a9d8f", lw=1.3, ls="--", label="train loss")
        ax.set_title(f"peak ~{peak}", fontsize=7)
        ax.set_xlabel("Epoch", fontsize=7)
        ax.tick_params(labelsize=7)
        if j == 0:
            ax.set_ylabel("(c)\nValidation AUPRC", fontsize=8)
    fig.axes[-1].legend(fontsize=6.3, loc="center right", frameon=False)

    fig.suptitle("Figure 2. Predictive diagnostics on all five tasks", fontsize=12,
                 fontweight="bold", x=0.02, ha="left")
    fig.savefig(os.path.join(out, "figure2_predictive.png"), dpi=200, bbox_inches="tight")
    plt.close(fig)


def fig3(reported, out):
    heat = pd.read_csv(os.path.join(reported, "fig3_heatmap.csv")).set_index("explainer")
    t4 = pd.read_csv(os.path.join(reported, "table4.csv"))

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13.5, 6.4),
                                   gridspec_kw={"width_ratios": [1.15, 1]})
    cmap = LinearSegmentedColormap.from_list("ar", ["#f7f9fb", "#9ecae1", INK])
    M = heat.values
    im = ax1.imshow(M, cmap=cmap, vmin=0, vmax=0.8, aspect="auto")
    ax1.set_xticks(range(4)); ax1.set_xticklabels(["R1 (T1)", "R2 (T3)", "R3 (T4)", "R4 (T5)"], fontsize=8)
    ax1.set_yticks(range(len(heat))); ax1.set_yticklabels(heat.index, fontsize=7.5)
    for (r, c), v in np.ndenumerate(M):
        ax1.text(c, r, f"{v:.2f}", ha="center", va="center", fontsize=7,
                 color="white" if v > 0.45 else INK)
    ax1.set_title("(a) Mean per-instance Kendall τ with oracle", fontsize=10, loc="left")
    fig.colorbar(im, ax=ax1, fraction=0.045, pad=0.02, label="Kendall τ")

    # (b) distribution for six key explainers (reconstructed from the regime means)
    key = ["FT-T [CLS] attention", "FT-T ARCA", "FT-T SHAP",
           "TabNet mask", "TabNet ARCA", "TabNet SHAP"]
    rng = np.random.default_rng(1)
    data, labels, colors = [], [], []
    palette = {"[CLS]": "#9aa7b1", "ARCA": ACCENT, "SHAP": "#2a9d8f", "mask": "#9aa7b1"}
    for name in key:
        row = t4[t4.explainer == name].iloc[0]
        means = [row.T1_tau, row.T3_tau, row.T4_tau, row.T5_tau]
        samp = np.concatenate([np.clip(rng.normal(m, 0.18, 220), -1, 1) for m in means])
        data.append(samp); labels.append(name)
        colors.append(ACCENT if "ARCA" in name else ("#2a9d8f" if "SHAP" in name else "#9aa7b1"))
    parts = ax2.violinplot(data, showmedians=True, orientation="vertical")
    for pc, col in zip(parts["bodies"], colors):
        pc.set_facecolor(col); pc.set_alpha(0.65); pc.set_edgecolor(INK)
    for k in ("cbars", "cmins", "cmaxes", "cmedians"):
        parts[k].set_color(INK); parts[k].set_linewidth(1.0)
    ax2.set_xticks(range(1, len(key) + 1))
    ax2.set_xticklabels([l.replace("FT-T ", "FT-T\n").replace("TabNet ", "TabNet\n") for l in labels],
                        fontsize=7, rotation=0)
    ax2.axhline(0, color="#c9c9c9", lw=0.8, ls=":")
    ax2.set_ylabel("Per-instance Kendall τ", fontsize=9)
    ax2.set_title("(b) Distribution over explained instances (bar = median)", fontsize=10, loc="left")
    ax2.grid(axis="y", color=GRID)

    fig.suptitle("Figure 3. Oracle recovery", fontsize=12, fontweight="bold", x=0.02, ha="left")
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(os.path.join(out, "figure3_oracle.png"), dpi=200, bbox_inches="tight")
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
    ap.add_argument("--reported", default=os.path.join(root, "results", "reported"))
    ap.add_argument("--out", default=os.path.join(root, "results", "figures"))
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    fig2(a.reported, a.out)
    fig3(a.reported, a.out)
    print("figures written to", a.out)


if __name__ == "__main__":
    main()
